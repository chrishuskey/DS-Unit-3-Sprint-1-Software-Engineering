"""
Module to generate random Acme Corp. products, and print a summary of them.
"""

from acme import Product
import random

# Constant lists:
PRODUCT_ADJECTIVES = ['Awesome', 'Shiny', 'Impressive', 'Portable', 'Improved']
RANDOM_NOUNS = ['Anvil', 'Catapult', 'Disguise', 'Mousetrap', '???']

def generate_products(num_products = 30):
    products_list = []
    for product in range(num_products):
        name = str(f"{random.sample(PRODUCT_ADJECTIVES, 1)} {random.sample(RANDOM_NOUNS, 1)}")
        price = random.randint(5, 100)
        weight = random.randint(5, 100)
        flammability =random.uniform(0.0, 2.5)
        new_product = Product(name, price, weight, flammability)
        products_list.append(new_product)
    return products_list

def inventory_report(list_of_products):
    print("ACME CORPORATION INVENTORY REPORT:")
    n_unique_products = len(set(list_of_products))
    print(f"Unique product names: {n_unique_products}")
    avg_price = sum([2, 22])
    print(f"Average price: {avg_price}")
    avg_weight = sum([3, 33])
    print(f"Average price: {avg_weight}")
    avg_flammability = sum([4, 44])
    print(f"Average price: {avg_flammability}")

if __name__ == '__main__':
     inventory_report(generate_products())
